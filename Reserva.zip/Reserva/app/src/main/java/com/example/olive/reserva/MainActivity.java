package com.example.olive.reserva;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends Activity implements SeekBar.OnSeekBarChangeListener
         {

    EditText nombre, edad, domicilio;
    TextView cuantasPersonas;
    Button fecha, hora;
    SeekBar barraPersonas;

    SimpleDateFormat fechaFormato, horaFormato;

    String nombreReserva = "";
    String numPersonas = "";
    String fechaSel = "", horaSel = "";
    Date fechaConv;
    String cuantasPersonasFormat = "";
    int personas = 1;

    Calendar calendario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cuantasPersonas = (TextView) findViewById(R.id.cuantasPersonas);
        barraPersonas = (SeekBar) findViewById(R.id.personas);

        fecha = (Button) findViewById(R.id.fecha);
        hora = (Button) findViewById(R.id.hora);

        barraPersonas.setOnSeekBarChangeListener(this);

        nombre = (EditText) findViewById(R.id.nombre);

        cuantasPersonasFormat = cuantasPersonas.getText().toString();
        cuantasPersonas.setText("Personas: 1");

        Calendar fechaSeleccionada = Calendar.getInstance();
        fechaSeleccionada.set(Calendar.HOUR_OF_DAY, 12);
        fechaSeleccionada.clear(Calendar.MINUTE);
        fechaSeleccionada.clear(Calendar.SECOND);


        fechaFormato = new SimpleDateFormat(fecha.getText().toString());
        horaFormato = new SimpleDateFormat("HH:mm");


        Date fechaReservacion = fechaSeleccionada.getTime();
        fechaSel = fechaFormato.format(fechaReservacion);
        fecha.setText(fechaSel);

        horaSel = horaFormato.format(fechaReservacion);

        hora.setText(horaSel);


    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        numPersonas = String.format(cuantasPersonasFormat,
                barraPersonas.getProgress() + 1);
        personas = barraPersonas.getProgress() + 1;
        cuantasPersonas.setText(numPersonas);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

             public void onTimeSet(TimePicker picker, int horas, int minutos) {
                 Calendar calendar = Calendar.getInstance();
                 calendar.set(Calendar.HOUR_OF_DAY, horas);
                 calendar.set(Calendar.MINUTE, minutos);

                 horaSel = horaFormato.format(calendar.getTime());
                 hora.setText(horaSel);
             }

             public void reserva(View v) {
                 Intent envia = new Intent(this, Actividad2.class);
                 Bundle datos = new Bundle();
                 datos.putString("nombre", nombre.getText().toString().trim());
                 datos.putInt("personas", personas);
                 datos.putString("fecha", fechaSel);
                 datos.putString("hora", horaSel);
                 envia.putExtras(datos);
                 finish();
                 startActivity(envia);
             }

}
